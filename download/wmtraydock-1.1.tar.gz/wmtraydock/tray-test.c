#include <X11/Xlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define SYSTEM_TRAY_REQUEST_DOCK 0
#define SYSTEM_TRAY_BEGIN_MESSAGE 1
#define SYSTEM_TRAY_CANCEL_MESSAGE 2

#define XEMBED_EMBEDDED_NOTIFY 0

int main(void)
{
    Display *display;
    int screen;
    Window root;
    Window tray;
    Window icon;

    Atom tray_selection;
    Atom tray_opcode;
    Atom xembed;

    XEvent event;

    display = XOpenDisplay(NULL);
    if (!display) {
        fprintf(stderr, "Cannot open display\n");
        return 1;
    }

    screen = DefaultScreen(display);
    root = RootWindow(display, screen);

    /*
     * Find the system tray manager.
     */
    tray_selection = XInternAtom(display, "_NET_SYSTEM_TRAY_S0", False);
    tray = XGetSelectionOwner(display, tray_selection);

    if (tray == None) {
        fprintf(stderr, "No system tray found\n");
        XCloseDisplay(display);
        return 1;
    }

    printf("Tray window: 0x%lx\n", tray);

    /*
     * Create our tray icon.
     */
    icon = XCreateSimpleWindow(
        display,
        root,
        0, 0,
        16, 16,
        0,
        BlackPixel(display, screen),
        WhitePixel(display, screen)
    );

    /*
     * Receive events from the tray.
     */
    XSelectInput(display, icon,
             StructureNotifyMask |
             PropertyChangeMask);

    tray_opcode = XInternAtom(
        display,
        "_NET_SYSTEM_TRAY_OPCODE",
        False
    );

    xembed = XInternAtom(
        display,
        "_XEMBED",
        False
    );

    /*
     * Ask the tray to dock us.
     */
    memset(&event, 0, sizeof(event));

    event.xclient.type = ClientMessage;
    event.xclient.window = tray;
    event.xclient.message_type = tray_opcode;
    event.xclient.format = 32;

    event.xclient.data.l[0] = CurrentTime;
    event.xclient.data.l[1] = SYSTEM_TRAY_REQUEST_DOCK;
    event.xclient.data.l[2] = icon;
    event.xclient.data.l[3] = 0;
    event.xclient.data.l[4] = 0;

    XSendEvent(
        display,
        tray,
        False,
        NoEventMask,
        &event
    );

    XFlush(display);

    printf("Tray icon: 0x%lx\n", icon);
    printf("Waiting for events...\n");

    while (1) {
        XNextEvent(display, &event);

        switch (event.type) {

        case ReparentNotify:
            printf(
                "ReparentNotify: parent=0x%lx\n",
                event.xreparent.parent
            );
            break;

        case ConfigureNotify:
            printf(
                "ConfigureNotify: %dx%d\n",
                event.xconfigure.width,
                event.xconfigure.height
            );
            break;

        case MapNotify:
            printf("MapNotify\n");
            break;

        case UnmapNotify:
            printf("UnmapNotify\n");
            break;

        case PropertyNotify:
            printf(
                "PropertyNotify: atom=0x%lx\n",
                event.xproperty.atom
            );
            break;

        case ClientMessage:

            if (event.xclient.message_type == xembed) {
                printf(
                    "XEMBED: opcode=%ld detail=%ld\n",
                    event.xclient.data.l[1],
                    event.xclient.data.l[2]
                );
            }

            break;

        case Expose:
            XClearWindow(display, icon);
            break;

        default:
            printf("Event type: %d\n", event.type);
            break;
        }
    }

    XCloseDisplay(display);
    return 0;
}
