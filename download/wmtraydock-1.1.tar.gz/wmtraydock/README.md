# wmTrayDock

![A screenshot of wmTrayDock showing two icons](screenshot.png)

A system tray application for use with the Window Maker windowmanager. 
It is based on the code of [Docker 1.5 by Ben Jansens](https://icculus.org/openbox/2/docker/). 
The original README is available in the file `README.orig`. 
Since the original software is intended as a systray for different window managers, I've decided to rollback the version to 1.0 
with this release, to indicate that this is a new product.

# FEATURES

- Small (default) and large icons
- Pagination, swap page by scrolling on the background (not the border)
- Notifying apps should have their icon placed in the first position of the first page, and that page is then opened automatically

# CHANGELOG

# 1.1:

- Added scrollable pagination
- Added notification sorting (if any application is notifying, that icon should show on first page)

## 1.0:
- Forced application to run in "Windowmaker mode"
- Forced icon size to be either 16 or 24 pixels, defaulting to 16 pixels
- Added background

# INSTALL

This will compile and install under `/usr/local`:

```bash
make && sudo make install
```

If you want to install under a different path, update the `Makefile`.
