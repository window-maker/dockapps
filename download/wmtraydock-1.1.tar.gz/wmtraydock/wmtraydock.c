#include "version.h"
#include "kde.h"
#include "icons.h"
#include "wmtraydock.h"
#include "net.h"

#include "wmtraydock-bkg.xpm"
#include "wmtraydock-mask.xbm"
#include <X11/xpm.h>
#include <X11/extensions/shape.h>

#include <assert.h>
#include <signal.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <X11/Xatom.h>
#include <X11/Xutil.h>

int argc;
char **argv;

Window win = None, hint_win = None, root = None;
gboolean wmaker = TRUE; /* WindowMakerMode!!! wheeee */
Display *display = NULL;
GSList *icons = NULL;
int width = 0, height = 0;
gboolean horizontal = TRUE; /* layout direction */
int icon_size = 16; // Default icon size to SMALL

#define ICON_SIZE_SMALL 16
#define ICON_SIZE_LARGE 22

#define wmtraydock_mask_width  64
#define wmtraydock_mask_height 64

#define PAGINATION_GRACE_US 1000000 /* 1 second */
static int current_page = 0;
static int page_count = 1;
static gint64 pagination_available_at = 0;

static Atom net_wm_user_time_atom;
static Atom prop_reorder_atoms[4]; /* WM_NAME, _NET_WM_NAME, WM_HINTS, _NET_WM_ICON */

static void init_atoms()
{
  net_wm_user_time_atom = XInternAtom(display, "_NET_WM_USER_TIME", False);

  prop_reorder_atoms[0] = XA_WM_NAME;
  prop_reorder_atoms[1] = XInternAtom(display, "_NET_WM_NAME", False);
  prop_reorder_atoms[2] = XA_WM_HINTS;
  prop_reorder_atoms[3] = XInternAtom(display, "_NET_WM_ICON", False);
}

static gboolean prop_triggers_reorder(Atom a)
{
  for (guint i = 0; i < G_N_ELEMENTS(prop_reorder_atoms); ++i)
    if (a != None && a == prop_reorder_atoms[i])
      return TRUE;
  return FALSE;
}

static char *display_string = NULL;
static gboolean exit_app = FALSE;

void signal_handler(int signal)
{
  switch (signal)
  {
  case SIGSEGV:
  case SIGFPE:
    g_printerr("Segmentation Fault or Critical Error encountered. "
               "Dumping core and aborting.\n");
    abort();

  case SIGPIPE:
  case SIGTERM:
  case SIGINT:
  case SIGHUP:
    exit_app = TRUE;
  }
}


void parse_cmd_line()
{
  int i;
  gboolean help = FALSE;

  for (i = 1; i < argc; i++) {
    if (0 == strcasecmp(argv[i], "-display")) {
      ++i;
      if (i < argc) {
        display_string = argv[i];
      } else {
        g_printerr("-display requires a parameter\n");
        help = TRUE;
      }
    } else if (0 == strcasecmp(argv[i], "-iconsize")) {
  ++i;
  if (i < argc) {
    if (0 == strcasecmp(argv[i], "small")) {
      icon_size = ICON_SIZE_SMALL;
    } else if (0 == strcasecmp(argv[i], "large")) {
      icon_size = ICON_SIZE_LARGE;
    } else {
      g_printerr("-iconsize must be either 'SMALL' or 'LARGE'\n");
      help = TRUE;
    }
  } else { /* argument doesn't exist */
    g_printerr("-iconsize requires a parameter\n");
    help = TRUE;
  }
} else {
      if (argv[i][0] == '-')
        help = TRUE;
    }


    if (help) {
      /* show usage help */
      g_print("%s - version %s\n", argv[0], VERSION);
      g_print("Copyleft 2025, Tobias Hellgren <thanius@chuggybumba.com>\n");
      g_print("Usage: %s [OPTIONS]\n\n", argv[0]);
      g_print("Options:\n");
      g_print("  -help             Show this help.\n");
      g_print("  -display DISPLAY  The X display to connect to.\n");
      g_print("  -iconsize SIZE    Can be either SMALL or LARGE. Defaults to\n"
              "                    SMALL.\n");
      exit(1);
    }
  }
}


void create_hint_win()
{
  XWMHints hints;
  XClassHint classhints;

  hint_win = XCreateSimpleWindow(display, root, 0, 0, 1, 1, 0, 0, 0);
  assert(hint_win);

  hints.flags = StateHint | WindowGroupHint | IconWindowHint;
  hints.initial_state = WithdrawnState;
  hints.window_group = hint_win;
  hints.icon_window = win;

  classhints.res_name = "wmtraydock";
  classhints.res_class = "wmtraydock";

  XSetWMProperties(display, hint_win, NULL, NULL, argv, argc,
                   NULL, &hints, &classhints);

  XMapWindow(display, hint_win);
}


void create_main_window()
{
  XWMHints hints;
  XTextProperty text;
  char *name = "wmtraydock";

  win = XCreateSimpleWindow(display, root, 0, 0, 64, 64, 0, 0, 0);
  assert(win);

  XStringListToTextProperty(&name, 1, &text);
  XSetWMName(display, win, &text);

  hints.flags = StateHint;
  hints.initial_state = WithdrawnState;
  XSetWMHints(display, win, &hints);

  create_hint_win();

  // Load background pixmap
  Pixmap bkg_pixmap;
  XpmCreatePixmapFromData(display, win, wmtraydock_bkg_xpm, &bkg_pixmap, NULL, NULL);
  XSetWindowBackgroundPixmap(display, win, bkg_pixmap);

  // Create shape mask from raw bitmap data
  Pixmap mask_pixmap = XCreateBitmapFromData(display, win, (const char *)wmtraydock_mask_bits, wmtraydock_mask_width, wmtraydock_mask_height);

  // Apply the shape mask to the window
  XShapeCombineMask(display, win, ShapeBounding, 0, 0, mask_pixmap, ShapeSet);

  // Free the mask pixmap if you don’t need it anymore
  XFreePixmap(display, mask_pixmap);

  // Redraw with new shape
  XClearWindow(display, win);
  XSync(display, False);
}

void reposition_icons()
{
  int x_start = (width % icon_size) / 2;
  int y_start = (height % icon_size) / 2;
  int columns = width / icon_size;
  int icons_per_page;
  int total_icons = g_slist_length(icons);
  int index = 0;
  GSList *it;

  if (icon_size == ICON_SIZE_LARGE)
    icons_per_page = 4; /* fifth icon starts the next page */
  else
    icons_per_page = 9; /* tenth icon starts the next page */

  page_count = (total_icons + icons_per_page - 1) / icons_per_page;

  g_print("Pagination: icon_size=%d total_icons=%d "
        "icons_per_page=%d page_count=%d\n",
        icon_size, total_icons, icons_per_page, page_count);

  if (page_count < 1)
      page_count = 1;

  if (current_page >= page_count)
      current_page = page_count - 1;

  for (it = icons; it != NULL; it = g_slist_next(it), index++) {
      TrayWindow *traywin = it->data;
      int page = index / icons_per_page;
      int page_index = index % icons_per_page;

      if (page != current_page) {
          XUnmapWindow(display, traywin->id);
          XSync(display, False);
          continue;
      }

      traywin->x = x_start + (page_index % columns) * icon_size;
      traywin->y = y_start + (page_index / columns) * icon_size;

      g_print("Configuring icon 0x%lx, page=%d, current=%d\n",
        traywin->id, page, current_page);

      XMoveResizeWindow(display,
                        traywin->id,
                        traywin->x,
                        traywin->y,
                        icon_size,
                        icon_size);

      XMapRaised(display, traywin->id);
      XSync(display, False);
  }
}

void change_page(int page)
{
  gint64 now = g_get_monotonic_time();

  if (page_count <= 1)
    return;

  if (now < pagination_available_at)
    return;

  pagination_available_at = now + PAGINATION_GRACE_US;

  if (page < 0)
    page = page_count - 1;
  else if (page >= page_count)
    page = 0;

  g_print("Changing to page %d\n", page);
  current_page = page;
  reposition_icons();
}

void icon_move_to_front(GSList *node)
{
  if (!node)
    return;

  if (node != icons) {
    icons = g_slist_remove_link(icons, node);
    icons = g_slist_concat(node, icons);
  }

  /* the icon is now at index 0, so jump to the page that shows it */
  current_page = 0;

  reposition_icons();
}

void event_loop()
{
  XEvent e;
  Window cover;
  GSList *it;

  while (!exit_app) {
    while (XPending(display)) {
      XNextEvent(display, &e);

      switch (e.type)
      {
        case PropertyNotify:
          if (e.xproperty.window == root &&
              e.xproperty.atom == kde_systray_prop) {
            XSelectInput(display, win, NoEventMask);
            kde_update_icons();
            XSelectInput(display, win,
                        StructureNotifyMask | ButtonPressMask);
            break;
          }

          for (it = icons; it != NULL; it = g_slist_next(it)) {
            TrayWindow *traywin = it->data;

            if (traywin->id == e.xproperty.window) {
              if (e.xproperty.atom != net_wm_user_time_atom) {
                char *name = XGetAtomName(display, e.xproperty.atom);

                g_print("ICON PROPERTY: window=0x%lx atom=0x%lx (%s)\n",
                        e.xproperty.window,
                        e.xproperty.atom,
                        name ? name : "?");

                if (name)
                  XFree(name);
              }

              if (prop_triggers_reorder(e.xproperty.atom))
                icon_move_to_front(it);

              break;
            }
          }

          break;

        case ConfigureNotify:
          if (e.xany.window != win) {
            /* find the icon it pertains to and beat it into submission */
            GSList *it;

            for (it = icons; it != NULL; it = g_slist_next(it)) {
              TrayWindow *traywin = it->data;
              if (traywin->id == e.xany.window) {
                /* ignore the echo of our own move; only fight self-resizes */
                if (e.xconfigure.x != traywin->x ||
                    e.xconfigure.y != traywin->y ||
                    e.xconfigure.width != icon_size ||
                    e.xconfigure.height != icon_size) {
                  g_print("Correcting icon 0x%lx geometry\n", traywin->id);
                  XMoveResizeWindow(display, traywin->id, traywin->x,
                                    traywin->y, icon_size, icon_size);
                }
                break;
              }
            }
            break;
          }

          /* briefly cover the entire containing window, which causes it and
            all of the icons to refresh their windows. finally, they update
            themselves when the background of the main window's parent changes.
          */
          cover = XCreateSimpleWindow(display, win, 0, 0, width, height, 0, 0, 0);
          XMapWindow(display, cover);
          XDestroyWindow(display, cover);

          break;

        case ButtonPress:
          if (e.xbutton.button != Button4 &&
              e.xbutton.button != Button5)
            break;

          Window target = e.xbutton.window;

          if (e.xbutton.subwindow != None)
            target = e.xbutton.subwindow;

          gboolean over_icon = FALSE;

          for (it = icons; it != NULL; it = g_slist_next(it)) {
            TrayWindow *traywin = it->data;

            if (traywin->id == target) {
              over_icon = TRUE;
              break;
            }
          }

          if (over_icon)
            break;

          if (target != win) {
            g_print("Ignoring wheel from window 0x%lx\n", target);
            break;
          }

          // Let's do this!

          if (e.xbutton.button == Button4)
            change_page(current_page - 1);
          else
            change_page(current_page + 1);

          break;

        case ReparentNotify:
          if (e.xreparent.parent == win) {
            /* icon was successfully reparented to us */
            break;
          }

          /* icon was reparented away */
          for (it = icons; it != NULL; it = g_slist_next(it)) {
            if (((TrayWindow *)it->data)->id == e.xreparent.window) {
              icon_remove(it);
              break;
            }
          }
          break;

        case DestroyNotify:
          for (it = icons; it != NULL; it = g_slist_next(it)) {
            if (((TrayWindow *)it->data)->id == e.xany.window) {
              icon_remove(it);
              break;
            }
          }
          break;

        case ClientMessage:
          if (e.xclient.message_type == net_opcode_atom &&
              e.xclient.format == 32 &&
              e.xclient.window == net_sel_win)
            net_message(&e.xclient);

        default:
          break;
      }
    }
    usleep(500000);
  }

  /* remove/unparent all the icons */
  while (icons) {
    /* do the remove here explicitly, cuz the event handler isn't going to
       happen anymore. */
    icon_remove(icons);
  }
}

int main(int c, char **v)
{
  struct sigaction act;

  argc = c; argv = v;

  act.sa_handler = signal_handler;
  act.sa_flags = 0;
  sigaction(SIGSEGV, &act, NULL);
  sigaction(SIGPIPE, &act, NULL);
  sigaction(SIGFPE, &act, NULL);
  sigaction(SIGTERM, &act, NULL);
  sigaction(SIGINT, &act, NULL);
  sigaction(SIGHUP, &act, NULL);

  parse_cmd_line();

  display = XOpenDisplay(display_string);
  if (!display) {
    g_printerr("Unable to open Display %s. Exiting.\n",
               DisplayString(display_string));
  }

  root = RootWindow(display, DefaultScreen(display));
  assert(root);

  // Forcing Windowmaker size (64x64-(1x2))
  width = height = 62;

  create_main_window();

  init_atoms();

  /* set up to find KDE systray icons, and get any that already exist */
  kde_init();

  net_init();

  XSelectInput(display, win, StructureNotifyMask | ButtonPressMask);

  event_loop();

  XCloseDisplay(display);

  return 0;
}
