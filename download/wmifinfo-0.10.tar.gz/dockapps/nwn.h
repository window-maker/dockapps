
int nwn_get_link(char *ifname);
