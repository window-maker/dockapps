#ifndef MOON_H
#define MOON_H

void MiniMoon(double, double*, double*);

#endif
