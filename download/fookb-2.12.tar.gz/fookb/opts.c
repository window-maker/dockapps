/* -*- C -*-
 * File: opts.c
 *
 * Created: Sun Sep 26 00:10:42 1999
 */

#ifdef DEBUG
#include <stdio.h>	/* puts () */
#endif

#include <string.h>

#include <X11/Xlib.h>		/* X Window standard header */
#include <X11/Xresource.h>	/* X resource manager stuff */

#include "fookb.h"
#include "opts.h"

void ParseOptions(argc, argv)
int * argc;
register char *argv[];
{
    XrmValue value;
    char *str_type[20];
    mydispname[0] = '\0';
    
    XrmParseCommand(&cmdlineDB, tbl, tblentr, "fookb", argc, argv);

#ifdef DEBUG
    puts("Hereiam");
#endif

/* TODO
   if (*argc != 1) HowToUseFookb(); */
    
    /* We should get display now -- we need it for access to other
       databases */
    if (XrmGetResource(cmdlineDB, "fookb.display", "Fookb.Display",
		       str_type, &value) == True) {
	(void) strncpy(mydispname, value.addr, (int) value.size);
#ifdef DEBUG
	puts(mydispname);
#endif
    }
    
}

void MoreOptions()
{
    
    XrmDatabase servDB, appDB;

    appDB = XrmGetFileDatabase("/usr/X11R6/lib/X11/app-defaults/Fookb");
    (void) XrmMergeDatabases(appDB, &finalDB); /* Fookb defaults file
						  added into final
						  database */

    /* Let's look: does xrdb load server defautls? (As a property of
       root window.) */
    if (XResourceManagerString(dpy) != NULL) {
	servDB = XrmGetStringDatabase(XResourceManagerString(dpy));
	XrmMergeDatabases(servDB, &finalDB);
    }

}
