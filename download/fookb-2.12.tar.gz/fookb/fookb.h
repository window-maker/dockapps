/*
 * fookb.h
 * 
 * (c) 1998,99 Alexey Vyskubov <alexey@pepper.spb.ru>
 *
 */

#ifndef FOOKB_H
#define FOOKB_H

void getGC(Window, GC *);
void update_window(Window, GC, unsigned int);

extern Display *dpy;		/* X display */
extern int scr;			/* X screen */
extern Window root;		/* X root window */
extern char mydispname[256];	/* X display name */

#endif	/* FOOKB_H */

