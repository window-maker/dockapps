/* -*- C -*-
 * File: opts.h
 *
 * (c) 1999 Alexey Vyskubov <alexey@pepper.spb.ru>
 *
 * Created: Sun Sep 26 00:10:23 1999
 */

#ifndef OPTS_H
#define OPTS_H

/* X Window resource management */
#include <X11/Xlib.h>
#include <X11/Xresource.h>

static int tblentr = 6;			/* There are 6 recognized
					   options */
static XrmOptionDescRec tbl[] = {
    {"-icon1",		".icon1",
			XrmoptionSepArg,
			(caddr_t) NULL},
    {"-icon2",		".icon2",
			XrmoptionSepArg,
			(caddr_t) NULL},
    {"-icon3",		".icon3",
			XrmoptionSepArg,
			(caddr_t) NULL},
    {"-icon4",		".icon4",
			XrmoptionSepArg,
			(caddr_t) NULL},
    {"-iconboom",	".iconBoom",
			XrmoptionSepArg,
			(caddr_t) NULL},
    {"-display",	".display",
			XrmoptionSepArg,
			(caddr_t) NULL}
};

extern XrmDatabase cmdlineDB;	/* Database for resources from command 
				   line */

extern XrmDatabase finalDB;	/* Database for resources from other
				   sources -- app-defaults and X
				   Window resources */

void ParseOptions(int * argc, register char *argv[]);	/* Parse
							   command
							   line
							   options */

void MoreOptions(void);					/* Parse
							   app-defaults
							   and X
							   resources
							   database */

#endif	/* OPTS_H */
