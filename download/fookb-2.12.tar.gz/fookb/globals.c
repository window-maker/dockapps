/* -*- C -*-
 * File: globals.c
 *
 * (c) 1999 Alexey Vyskubov <alexey@pepper.spb.ru>
 *
 * Created: Sun Sep 26 13:54:08 1999
 */

#include <X11/Xlib.h>
#include <X11/Xresource.h>

Display *dpy;		/* X Window display */
int scr;		/* X Window screen */
Window root;		/* X root window */
char mydispname[256];	/* X display name */

XImage *stupid_picture[5];	/* Icons for fookb */

XrmDatabase cmdlineDB;		/* X resource database generated from
				   command line */
XrmDatabase finalDB;		/* X resource database generated from
				   app-defaults and X resource
				   database */
