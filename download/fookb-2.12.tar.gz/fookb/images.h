/*
 * images.h
 * 
 * (c) 1998,99 Alexey Vyskubov <alexey@pepper.spb.ru>
 */

#ifndef IMAGES_H
#define IMAGES_H

int get_one_image(char *, int);
void read_images(void);
char *get_me_name(int);

extern XImage *stupid_picture[5];	/* Icons for fookb */

#endif	/* IMAGES_H */
