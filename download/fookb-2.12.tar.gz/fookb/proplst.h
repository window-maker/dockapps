/* -*- C -*-
 * File: proplst.h
 *
 * (c) 1999 Alexey Vyskubov <alexey@pepper.spb.ru>
 * Created: Sun Sep 26 19:49:36 1999
 */

#ifndef PROPLST_H
#define PROPLST_H

#ifdef HAVE_LIBPROPLIST
#ifdef HAVE_PROPLIST_H
#define PROPLIST
#endif
#endif

#endif	/* PROPLST_H */
