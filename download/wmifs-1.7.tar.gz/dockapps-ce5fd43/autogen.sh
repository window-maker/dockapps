#!/bin/sh
autoreconf --force --verbose --install
