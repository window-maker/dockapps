#include "xobjects.h"

Pixmap TileImage = 0 ;
Pixmap TileMask = 0 ;
Pixmap HighlightImage = 0 ;
Pixmap HighlightMask = 0 ;
Pixmap HighlightBehindMask = 0 ;
Pixmap ButtonBarImage = 0 ;
Window ButtonBarWindow = 0 ;
Window WMFrame = 0 ;

