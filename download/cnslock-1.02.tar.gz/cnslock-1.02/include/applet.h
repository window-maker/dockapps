
void make_new_cnslock_dockapp(int);
