void init_kleds(void);
int check_kleds(void);