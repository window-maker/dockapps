
#ifndef ABOUT_H
#define ABOUT_H

void about_dismiss(GtkWidget *wid,gpointer data);
void applet_about (GtkWidget * widget, gpointer data);

#endif
