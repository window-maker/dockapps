/*
 * images.c
 *
 * (c) 1998, 1999, 2000, 2001 Alexey Vyskubov <alexey@pepper.spb.ru>
 */

#include <stdio.h>		/* puts() */

/* Xpm fun */
#include <X11/xpm.h>

#include "proplst.h"
#include "fookb.h"
#include "params.h"
#include "images.h"

int get_one_image(name, index)
char *name;
int index;
{
	int foo;

	foo = XpmReadFileToImage(dpy, name, &stupid_picture[index],
				 NULL, NULL);
	return (foo);
}

void read_images()
{
	int i;
	int res;
	int status = 0;

	for (i = 0; i < 5; i++) {

		switch (i) {
		case 0:
			res = get_one_image(read_param("Icon1"), 0);
			break;
		case 1:
			res = get_one_image(read_param("Icon2"), 1);
			break;
		case 2:
			res = get_one_image(read_param("Icon3"), 2);
			break;
		case 3:
			res = get_one_image(read_param("Icon4"), 3);
			break;
		default:
			res = get_one_image(read_param("IconBoom"), 4);
			break;
		}

		switch (res) {
		case XpmOpenFailed:
			puts("Xpm file open failed:");
			status = 1 << 5;
			break;
		case XpmFileInvalid:
			puts("Xpm file is invalid:");
			status = 1 << 6;
			break;
		case XpmNoMemory:
			puts("No memory for open xpm file:");
			status = 1 << 7;
			break;
		default:
		}

		if (!(status == 0)) {
			status += 1 << i;
			switch (i) {
			case 0:
				puts(read_param("Icon1"));
				break;
			case 1:
				puts(read_param("Icon2"));
				break;
			case 2:
				puts(read_param("Icon3"));
				break;
			case 3:
				puts(read_param("Icon4"));
				break;
			case 4:
				puts(read_param("IconBoom"));
				break;
			default:
				puts("UNKNOWN ERROR! PLEASE REPORT!!!");
				exit(-2);
			}
			exit(status);
		}
	}

}

void update_window(win, gc, whattodo)
Window win;
GC gc;
unsigned int whattodo;
{
	XPutImage(dpy, win, gc, stupid_picture[whattodo], 0, 0, 0, 0, 48,
		  48);
}
