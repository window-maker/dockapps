#ifndef types_h_
#define types_h_

typedef int bool ;
#ifndef false
#define false (0)
#endif
#ifndef true
#define true (1)
#endif

#ifndef EOS
#define EOS '\0'
#endif

#endif /* types_h_ */
