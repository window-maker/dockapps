#define VERSION "wmCapShare 0.1"
