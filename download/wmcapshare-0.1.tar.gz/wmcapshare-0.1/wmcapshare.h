#ifndef WMCAPSHARE_H
#define WMCAPSHARE_H

#define CAP_WAIT 0
#define CAP_RECIEVE 1
#define CAP_CONNECT 2

void updateDisplay();
#endif
