int upower_supported(void);
int upower_read(int battery, apm_info *info);
