int simplehal_supported(void);
int simplehal_read(int battery, apm_info *info);
