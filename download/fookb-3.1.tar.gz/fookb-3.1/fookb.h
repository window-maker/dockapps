/*
 * fookb.h
 * 
 * (c) 1998-2004 Alexey Vyskubov <alexey@mawhrin.net>
 *
 */

#ifndef FOOKB_H
#define FOOKB_H

extern char mydispname[256];	/* X display name */

#endif				/* FOOKB_H */
