/*
 * params.h
 *
 * (c) 1999, 2000, 2001 Alexey Vyskubov <alexey@pepper.spb.ru>
 *
 */

#ifndef PARAMS_H
#define PARAMS_H

#ifdef PROPLIST
#include <proplist.h>

#ifdef WMAKER
#define DEFAULTS_FILE "~/GNUstep/Defaults/FOOkb"
#else
#define DEFAULTS_FILE "~/.fookb"
#endif				/* WMAKER */

#endif				/* PROPLIST */

#include <X11/Xlib.h>		/* X Window standard header */
#include <X11/Xresource.h>	/* X resource manager stuff */

char *read_param(char *);

#endif				/* PARAMS_H */
