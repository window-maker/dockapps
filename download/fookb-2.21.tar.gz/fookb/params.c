#include <stdio.h>
#include <string.h>		/* strlen & strcat */
#include <ctype.h>		/* toupper */
#include <stdlib.h>
#ifdef HAVE_LIBPROPLIST
#ifdef HAVE_PROPLIST_H
#define PROPLIST
#endif
#endif
#include "params.h"
#include "opts.h"

char *read_param(string)
char *string;
{

	XrmValue xvalue;

#ifdef HAVE_LIBPROPLIST
#ifdef HAVE_PROPLIST_H
#define PROPLIST
#endif
#endif

#ifdef PROPLIST
	proplist_t pl, value;
#endif

	char *newstring;
	char *newString;
	char *result;
	char *str_type[20];

	newstring = (char *) malloc(7 + strlen(string));	/* 7 is
								   strlen("fookb.") + 1 */
	newString = (char *) malloc(7 + strlen(string));	/* The same */

	strcpy(newstring, "fookb.");
	strcpy(newString, "Fookb.");

	strcat(newstring, string);
	strcat(newString, string);
	newstring[6] = tolower(newstring[6]);
	newString[6] = toupper(newString[6]);

/* Command line parameters take precedence over all */

	if (XrmGetResource(cmdlineDB, newstring, newString, str_type,
			   &xvalue) == True) {
		result = (char *) malloc((int) xvalue.size + 1);
		strncpy(result, xvalue.addr, (int) xvalue.size);
		result[(int) xvalue.size + 1] = '\0';
		return result;
	}
#ifdef PROPLIST

	pl = PLGetProplistWithPath(DEFAULTS_FILE);

	if (!pl) {
		puts("Cannot open config file: ");
		puts(DEFAULTS_FILE);
		exit(20);
	}

	value = PLGetDictionaryEntry(pl, PLMakeString(string));

	if (!value) {
		puts("Cannot find in config file value for: ");
		puts(string);
		exit(21);
	}

	result = (char *) malloc(strlen(PLGetString(value)) + 1);
	strcpy(result, PLGetString(value));
	return result;

#else				/* PROPLIST */

	if (XrmGetResource(finalDB, newstring, newString, str_type,
			   &xvalue) == True) {
		result = (char *) malloc((int) xvalue.size + 1);
		strncpy(result, xvalue.addr, (int) xvalue.size);
		result[(int) xvalue.size + 1] = '\0';
		return result;
	} else {
		printf("Fatal error: cannot find configuration parameter %s\n", newstring);
		exit(25);
	}

#endif

}
