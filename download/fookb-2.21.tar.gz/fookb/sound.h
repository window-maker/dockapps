/*
 * File: sound.h
 *
 * (c) 1999, 2000, 2001 Alexey Vyskubov <alexey@pepper.spb.ru>
 *
 * Created: Sun Sep 19 16:52:45 1999
 */

#ifndef SOUND_H
#define SOUND_H

void drip(void);

#endif
