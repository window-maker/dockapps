#ifndef _WMACPI_H_
#define _WMACPI_H_

#include "libacpi.h"

/* we need to make these available generally. */
int battery_no;

#endif /* _WMACPI_H_ */
