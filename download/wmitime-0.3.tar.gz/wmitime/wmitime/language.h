// language.h

static char daynames[7][3] =
{
    {"Su"},
    {"Mo"},
    {"Tu"},
    {"We"},
    {"Th"},
    {"Fr"},
    {"Sa"}
};

static char monthnames[12][4] =
{
    {"Jan"},
    {"Feb"},
    {"Mar"},
    {"Apr"},
    {"May"},
    {"Jun"},
    {"Jul"},
    {"Aug"},
    {"Sep"},
    {"Oct"},
    {"Nov"},
    {"Dec"}
};







