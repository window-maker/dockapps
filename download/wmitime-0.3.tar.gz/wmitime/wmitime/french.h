// french.h
// Created by Pierre-Marie.Allemand@capway.com
// 08-jan-1999

static char daynames[7][3] =
{
    {"Di"},
    {"Lu"},
    {"Ma"},
    {"Me"},
    {"Je"},
    {"Ve"},
    {"Sa"}
};

static char monthnames[12][4] =
{
    {"Jan"},
    {"Fev"},
    {"Mar"},
    {"Avr"},
    {"Mai"},
    {"Jun"},
    {"Jui"},
    {"Aou"},
    {"Sep"},
    {"Oct"},
    {"Nov"},
    {"Dec"}
};
