/*
 * File: globals.c
 *
 * (c) 1998-2002 Alexey Vyskubov <alexey@mawhrin.net>
 *
 */

#include <X11/Xlib.h>
#include <X11/Xresource.h>

Display *dpy;			/* X Window display */
int scr;			/* X Window screen */
Window root;			/* X root window */
char mydispname[256];		/* X display name */

XImage *stupid_picture[5];	/* Icons for fookb */

XrmDatabase cmdlineDB;		/* X resource database generated from
				   command line */
XrmDatabase finalDB;		/* X resource database generated from
				   app-defaults and X resource
				   database */
