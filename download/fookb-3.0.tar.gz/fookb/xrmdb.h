extern XrmDatabase cmdlineDB;	/* Database for resources from command 
				   line */

extern XrmDatabase finalDB;	/* Database for resources from other
				   sources -- app-defaults and X
				   Window resources */

