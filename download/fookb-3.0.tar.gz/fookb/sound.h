/*
 * File: sound.h
 *
 * (c) 1998-2002 Alexey Vyskubov <alexey@mawhrin.net>
 *
 */

#ifndef SOUND_H
#define SOUND_H

void drip(void);

#endif
